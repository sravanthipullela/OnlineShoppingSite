﻿insert into Product(id,CategoryId,Picture,Price,Quantity,[Description]) values(1,1,'1.jpg',650,1,'True Blue Men Navy Blue Printed Regular Fit Casual Shirt');
insert into Product (id,CategoryId,Picture,Price,Quantity,[Description])values(2,1,'2.jpg',800,1,'SVANIK BLACK SOLID COTTON SHIRT');
insert into Product (id,CategoryId,Picture,Price,Quantity,[Description])values(3,1,'3.jpg',950,1,'Royal Blue Casual Shirt');
insert into Product (id,CategoryId,Picture,Price,Quantity,[Description])values(4,1,'4.jpg',900,1,' New fashion men linen shirt long sleeve casual mens shirts breathable slim Fit dress shirts');
insert into Product (id,CategoryId,Picture,Price,Quantity,[Description])values(5,1,'5.jpg',700,1,'Burberry Cotton Oxford Shirt White in Black for Men - Lyst');
insert into Product (id,CategoryId,Picture,Price,Quantity,[Description])values(6,2,'6.jpg',1200,1,'Latest fashion designer saree for stylish Women');
insert into Product (id,CategoryId,Picture,Price,Quantity,[Description])values(7,2,'7.jpg',2500,1,'Latest Pakistani Designer Saree Designs 2020 For Women ');
insert into Product (id,CategoryId,Picture,Price,Quantity,[Description])values(8,2,'8.jpg',1500,1,'Modern Georgette saree ');
insert into Product (id,CategoryId,Picture,Price,Quantity,[Description])values(9,2,'9.jpg',1000,1,'Heavy Embrodidery Work saree');
insert into Product (id,CategoryId,Picture,Price,Quantity,[Description])values(10,2,'10.jpg',900,1,'Exclusive Party wear saree');
select *from Product

insert into ProductCategory values(1,'Shirts');
insert into ProductCategory values(2,'sarees');
select* from ProductCategory
select*from CartItem

select Id,CategoryId,Price,Quantity,Description,Picture from Product where CategoryId=(select CategoryId from ProductCategory where categoryname like '%Shirts%')
select*from Product where Id=2