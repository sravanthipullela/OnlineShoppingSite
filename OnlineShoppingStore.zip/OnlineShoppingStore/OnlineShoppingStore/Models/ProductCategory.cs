﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineShoppingStore.Models
{
    public class ProductCategory
    {
        //Category Id
        [Required]
        public int CategoryId { get; set; }
        //category Name
        [Required]
        public string CategoryName { get; set; }
    }
}