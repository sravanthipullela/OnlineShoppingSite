﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OnlineShoppingStore.Models
{
    public class CartItem
    {
        //Cart Id
        public int Id { get; set; }
        //Product Price
        public double Price { get; set; }
        //Product Quantity
        public int Quantity { get; set; }
       
    }
}