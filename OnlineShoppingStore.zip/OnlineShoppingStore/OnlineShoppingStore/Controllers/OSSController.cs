﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net.Http;
using Newtonsoft.Json;


using OnlineShoppingStore.Models;

namespace OnlineShoppingStore.Controllers
{
      public class OSSController : Controller
    {
      
        // GET: OSS
       /// <summary>
       /// This method will be called first and redirects to its corresponding View page
       /// </summary>
       /// <returns>HomePage View To the Client</returns>
        public ActionResult HomePage()
        {
            var lstc = new List<ProductCategory>();
            var lstp = new List<Product>();
            using (var Client = new HttpClient())
            {
                Client.BaseAddress = new Uri("http://localhost:65234/api/OSS/");
                var result = Client.GetStringAsync("GetCategories").Result;
                lstc = JsonConvert.DeserializeObject<List<ProductCategory>>(result);
            }
            return View();
        }

        /// <summary>
        /// This method will be called first and redirects to its corresponding View page
        /// </summary>
        /// <param name="CategoryName"></param>
        /// <returns>Products View to the Client</returns>

        [HttpPost]
             public ActionResult Products(string CategoryName)
             {
                var lstc = new List<ProductCategory>();
                var lstp = new List<Product>();
                 using (var Client = new HttpClient())
                    {
                       Client.BaseAddress = new Uri("http://localhost:65234/api/OSS/");
                       var result = Client.GetStringAsync("SearchCategoryByName/"+CategoryName).Result;
                        lstp = JsonConvert.DeserializeObject<List<Product>>(result);

                    }
                    return View(lstp);
             }

        /// <summary>
        /// This method will be called first and redirects to its corresponding View page
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>Product Details View to the Client</returns>
        [HttpGet]
        public ActionResult ProductDetails(int Id)
        {
            var lstc = new List<ProductCategory>();
            var lstp = new List<Product>();
            using (var Client = new HttpClient())
            {
                Client.BaseAddress = new Uri("http://localhost:65234/api/OSS/");
                var result = Client.GetStringAsync("SearchProductById/" + Id).Result;
                lstp = JsonConvert.DeserializeObject<List<Product>>(result);
            }
            return View(lstp);
        }

        /// <summary>
        /// This method will be called first and redirects to its corresponding View page
        /// </summary>
        /// <returns>Add To Cart View to the client</returns>
        [HttpGet]
        public ActionResult AddToCart()
        {
            return View();
        }

        /// <summary>
        /// This method will be called first and redirects to its corresponding View page
        /// </summary>
        /// <param name="item"></param>
        /// <returns>Add To Cart View to the client</returns>
        [HttpPost]
        public ActionResult AddToCart(CartItem item)
        {
            if (Session["cart"] == null)
            {
                var cartlst = new List<CartItem>();
                cartlst.Add(item);
                Session.Add("cart", cartlst);
            }
            else
            {
                var cartlst = (List<CartItem>)Session["cart"];
                cartlst.Add(item);
                Session.Add("cart", cartlst);
            }
            return RedirectToAction("Product");
        }

        /// <summary>
        /// This method will be called first and redirects to its corresponding View page
        /// </summary>
        /// <returns>Display Cart View to the client</returns>
        public ActionResult DisplayCart()
        {
            var cartlst = (List<CartItem>)Session["cart"];
            Session.Add("Cart List", cartlst);
            return View("cartlst");
        }
        /// <summary>
        ///  This method will be called first and redirects to its corresponding View page
        /// </summary>
        /// <returns>PostTocart View to the client</returns>
        public ActionResult PostToCart()
        {
            Uri uri = new Uri("http://localhost:65234/api/OSS/");
            var cartlst = ((List<CartItem>)Session["cart"]);
            using(var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.PostAsJsonAsync<List<CartItem>>("OSS/AddToCart", cartlst).Result;
                if(result.IsSuccessStatusCode==true)
                {
                    ViewData.Add("msg", "Product Added Successfully!!");
                }
                else
                {
                    ViewData.Add("msg", "Not Added");
                }
            }
            return View(cartlst);


        }

        /// <summary>
        /// This method will be called first and redirects to its corresponding View page
        /// </summary>
        /// <returns>Create View to the Client </returns>
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// This method will be called first and redirects to its corresponding View page
        /// </summary>
        /// <param name="p"></param>
        /// <returns>Create View To the client</returns>
        [HttpPost]
        public ActionResult Create(Product p)
        {
            Uri uri = new Uri("http://localhost:65234/api/");
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.PostAsJsonAsync("OSS/", p).Result;
                if (result.IsSuccessStatusCode == true)
                {
                    ViewData.Add("msg", "Record inserted");
                }
                else { ViewData.Add("msg", "Record not insertred"); }
            }
            return View();

        }


        /// <summary>
        /// This method will be called first and redirects to its corresponding View page
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>Delete View To the Client</returns>
        [HttpGet]
        public ActionResult Delete(int Id)
        {
            Uri uri = new Uri("http://localhost:65234/api/");
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.DeleteAsync("OSS/" + Id).Result;
                if (result.IsSuccessStatusCode == true)
                {
                    ViewData.Add("msg", "record deleted");
                }
                else
                {
                    TempData.Add("msg", "Delete Error");
                }
            }
            return RedirectToAction("Index");
        }

        /// <summary>
        /// This method will be called first and redirects to its corresponding View page
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>Edit View To the Client</returns>
        [HttpGet]
        public ActionResult Edit(int Id)
        {
            Uri uri = new Uri("http://localhost:65234/api/");
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("OSS/" + Id).Result;
                var pr = JsonConvert.DeserializeObject<Product>(result);
                return View(pr);
            }
        }

        /// <summary>
        /// This method will be called first and redirects to its corresponding View page
        /// </summary>
        /// <param name="p"></param>
        /// <returns>Edit View to the Client</returns>
        [HttpPost]
        public ActionResult Edit(Product p)
        {
            Uri uri = new Uri("http://localhost:65234/api/");
            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.PutAsJsonAsync("OSS/" + p.Id, p).Result;
                if (result.IsSuccessStatusCode == true)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    ViewData.Add("msg", "update Error");
                }
                return View();

            }

        }

        /// <summary>
        /// This method will be called first and redirects to its corresponding View page
        /// </summary>
        /// <returns>PlaceOrder View to the client</returns>
        [HttpGet]
        public ActionResult PlaceOrder()
        {
            return View();

        }
      
    }
}
