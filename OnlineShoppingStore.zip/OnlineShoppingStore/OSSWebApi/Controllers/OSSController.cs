﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using OSSBusinessLib;
using OSSEntitiesLib;

namespace OSSWebApi.Controllers
{
    public class OSSController : ApiController
    {
        /// <summary>
        /// This method takes data from BusinessLayer and redirects to MVC's Controller
        /// </summary>
        /// <returns>List of Product Categories</returns>
        [Route("api/OSS/GetCategories")]
         public List<ProductCategory> GetAllCategories()
        {
            OSSBusinessLayer bll = new OSSBusinessLayer();
            var lstc = bll.GetAllCategories();
            return lstc;
        }

        /// <summary>
        /// This method takes data from BusinessLayer and redirects to MVC's Controller
        /// </summary>
        /// <param name="CategoryName"></param>
        /// <returns>List of Products</returns>
        [Route("api/OSS/SearchCategoryByName/{CategoryName}")]
        public List<Product> GetCategoryByName(string CategoryName)
        {
            OSSBusinessLayer bll = new OSSBusinessLayer();
            var lstp = bll.GetCategoryByName(CategoryName);
            return lstp;
        }

        /// <summary>
        /// This method takes data from BusinessLayer and redirects to MVC's Controller
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>List of Products</returns>
        [Route("api/OSS/SearchProductById/{Id}")]
        public List<Product> GetProductByProductId(int Id)
        {
            OSSBusinessLayer bll = new OSSBusinessLayer();
            var lstp = bll.GetProductByProductId(Id);
            return lstp;
        }

        /// <summary>
        /// This method takes data from BusinessLayer and redirects to MVC's Controller
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>CartItems</returns>
        [Route("api/OSS/AddToCart/{CartList}")]
        public void GetCart(List<CartItem> cartlst)
        {
            OSSBusinessLayer bll = new OSSBusinessLayer();
            bll.AddToCart(cartlst);
        }

        /// <summary>
        /// This method takes data from BusinessLayer and redirects to MVC's Controller
        /// </summary>
        /// <param name="p"></param>
        /// <returns>Add's Product</returns>
        public HttpResponseMessage Post([FromBody] Product p)
        {
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "Record added");
            try
            {
                OSSBusinessLayer bll = new OSSBusinessLayer();
                bll.AddProduct(p);
            }
            catch (Exception ex)
            {
                errRes = Request.CreateErrorResponse(HttpStatusCode.NotFound, "Could not insert Record");
            }
            return errRes;
        }

        /// <summary>
        /// This method takes data from BusinessLayer and redirects to MVC's Controller
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>Delete's Product</returns>
        public HttpResponseMessage Delete(int Id)
        {
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "Record Found");
            try
            {
                OSSBusinessLayer bll = new OSSBusinessLayer();
                bll.DeleteProductById(Id);
            }
            catch (Exception ex)
            {
                errRes = Request.CreateErrorResponse(HttpStatusCode.NotFound, "ProductId not found");
            }
            return errRes;

        }

        /// <summary>
        /// This method takes data from BusinessLayer and redirects to MVC's Controller
        /// </summary>
        /// <param name="p"></param>
        /// <returns>Update's Product</returns>
        public HttpResponseMessage put([FromBody] Product p)
        {
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "Record Updated");
            try
            {
                OSSBusinessLayer bll = new OSSBusinessLayer();
                bll.UpdateProductById(p);
            }
            catch
            {
                errRes = Request.CreateErrorResponse(HttpStatusCode.NotFound, "Updation Error!!!");
            }
            return errRes;
        }

    }
}
