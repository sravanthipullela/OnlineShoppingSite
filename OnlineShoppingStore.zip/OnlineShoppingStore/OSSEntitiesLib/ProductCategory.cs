﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSSEntitiesLib
{
    public class ProductCategory
    {
        //Category Id
        public int CategoryId { get; set; }
        //Category Name 
        public string CategoryName { get; set; }

    }
}
