﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSSEntitiesLib
{
    public class Product
    {
        //Product Id
        public int Id { get; set; }
        //Product Price
        public double Price { get; set; }
        //Product Quantity
        public int Quantity { get; set; }
        //Product Description
        public string Description { get; set; }
        //Product Picture
        public string Picture { get; set; }
        
    }
}
