﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OSSDataAccessLib;
using OSSExceptionLib;
using OSSEntitiesLib;

namespace OSSBusinessLib
{
    public class OSSBusinessLayer : IOSSBusinessLayer
    {
        /// <summary>
        /// This method is linked to data accesslayer's GetAllCategories
        /// </summary>
        /// <returns>List of Product Categories are retrived</returns>
        public List<ProductCategory> GetAllCategories()
        {
            try
            {
                OSSDataAccessLayer dal = new OSSDataAccessLayer();
                var lstc = dal.GetAllCategories();
                return lstc;

            }
           catch(OSSException ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// This method is linked to data accesslayer's GetCategoryByName
        /// </summary>
        /// <param name="CategoryName"></param>
        /// <returns>List of Product are retrived</returns>
        public List<Product> GetCategoryByName(string CategoryName)
        {
            try
            {
                OSSDataAccessLayer dal = new OSSDataAccessLayer();
                var lstp = dal.GetCategoryByName(CategoryName);
                return lstp;

            }
            catch (OSSException ex)
            {
                throw ex;
            }
        }
        /// <summary>
        ///  This method is linked to data accesslayer's GetProductByProductId
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>List of Product are retrived</returns>

        public List<Product> GetProductByProductId(int Id)
        {
            try
            {
                OSSDataAccessLayer dal = new OSSDataAccessLayer();
                var lstp = dal.GetProductByProductId(Id);
                return lstp;

            }
            catch (OSSException ex)
            {
                throw ex;
            }
        }
        /// <summary>
        ///  This method is linked to data accesslayer's AddProduct
        /// </summary>
        /// <param name="p"></param>

        public void AddProduct(Product p)
        {
            try
            {
                OSSDataAccessLayer dal = new OSSDataAccessLayer();
                  dal.AddProduct(p);
            }
            catch (OSSException ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// This method is linked to data accesslayer's DeleteProductById
        /// </summary>
        /// <param name="Id"></param>

        public void DeleteProductById(int Id)
        {
            try
            {
                OSSDataAccessLayer dal = new OSSDataAccessLayer();
                dal.DeleteProductById(Id);

            }
            catch (OSSException ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// This method is linked to data accesslayer's UpdateProductById
        /// </summary>
        /// <param name="p"></param>
        public void UpdateProductById(Product p)
        {
            try
            {
                OSSDataAccessLayer dal = new OSSDataAccessLayer();
                dal.UpdateProductById(p);

            }
            catch (OSSException ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// This method is linked to data accesslayer's AddToCart
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>Added Cart Items</returns>
        public void AddToCart(List<CartItem> cartlst)
        {
            try
            {
                OSSDataAccessLayer dal = new OSSDataAccessLayer();
                dal.AddToCart(cartlst);
            }
            catch (OSSException ex)
            {
                throw ex;
            }
        }

    }
}
