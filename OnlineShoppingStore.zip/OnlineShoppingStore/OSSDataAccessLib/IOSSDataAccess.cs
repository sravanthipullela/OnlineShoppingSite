﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OSSEntitiesLib; //reference for entities

namespace OSSDataAccessLib
{
    public interface IOSSDataAccess
    {
        /// <summary>
        /// Method Signature for GetAllCategories
        /// </summary>
        /// <returns>List of Product Categories</returns>
        List<ProductCategory> GetAllCategories();

        /// <summary>
        /// Method Signature for Get Products basing on the Category Name.
        /// </summary>
        /// <param name="CategoryName"></param>
        /// <returns>List Of Products</returns>
        List<Product> GetCategoryByName(string CategoryName);

        /// <summary>
        /// Method Signature for Get All the Product Details basing on the Product Id along
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>List of Product with Complete Details</returns>
        List<Product> GetProductByProductId(int Id);

        /// <summary>
        /// Method Signature to Add Product to database
        /// </summary>
        /// <param name="p"></param>
        void AddProduct(Product p);

        /// <summary>
        /// Method Signature to Delete Product from Database Using Product Id
        /// </summary>
        /// <param name="Id"></param>
        void DeleteProductById(int Id);

        /// <summary>
        ///  Method Signature to Update Product using Product Id.
        /// </summary>
        /// <param name="p"></param>
        void UpdateProductById(Product p);

        /// <summary>
        /// Method Signature to Add Products to the Cart.
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        //CartItem AddToCart(int Id);
        void AddToCart(List<CartItem> cartlst);
    }
}
