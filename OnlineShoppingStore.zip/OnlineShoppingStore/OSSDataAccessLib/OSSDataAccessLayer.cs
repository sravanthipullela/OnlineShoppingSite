﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient; 
using OSSEntitiesLib;
using OSSExceptionLib;

using System.Configuration;

namespace OSSDataAccessLib
{
    public class OSSDataAccessLayer : IOSSDataAccess
    {
        //Creating references for Sql Connection and Command
        SqlConnection con;
        SqlCommand cmd;
      
        public OSSDataAccessLayer()
        {
            //Configure Connection Object
            con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["sqlconstr"].ConnectionString;
        }

        /// <summary>
        /// This method retrives all the Products Categories that are in the database.
        /// </summary>
        /// <returns>List of Product Categories</returns>

        public List<ProductCategory> GetAllCategories()
        {
            List<ProductCategory> lstproducts = new List<ProductCategory>();
            try
            {
                //configure Command for SELECT Statement
                cmd = new SqlCommand();
                cmd.CommandText = "select* from ProductCategory";
                //Attach Connection with the command
                cmd.Connection = con;
                //Open Connection
                con.Open();
                //Execute the select command from database
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    ProductCategory product = new ProductCategory
                    {
                        CategoryId = (int)sdr[0],

                        CategoryName = sdr[1].ToString()
                    };
                    lstproducts.Add(product);
                }
                //Close the data reader and connection
                sdr.Close();

            }
            //Handles Sql Exception
            catch (SqlException ex)
            {
                throw new OSSException(ex.Message);

            }
            //Handles any Other Exception
            catch (Exception ex)
            {
                throw new OSSException(ex.Message);
            }
            finally
            {
                //Close Connection
                con.Close();

            }
            //return all the records using collection
            return lstproducts;
        }
        /// <summary>
        /// This method retrives All the Products basing on the Category Name.
        /// </summary>
        /// <param name="CategoryName"></param>
        /// <returns>List Of Products</returns>
        public List<Product> GetCategoryByName(string CategoryName)
        {
            List<Product> lstproduct = new List<Product>();
            try
            {
                //configure Command for SELECT Statement
                cmd = new SqlCommand();
                cmd.CommandText = "select Id,CategoryId,Price,Quantity,Description,Picture from Product where CategoryId=(select CategoryId from ProductCategory where categoryname like @cn)";
                //Pass Value to the Parameter
                cmd.Parameters.Clear();
                //supply values to the parameters of the command
                cmd.Parameters.AddWithValue("@cn", "%" + CategoryName + "%");
                //specify the type of command
                cmd.CommandType = CommandType.Text;
                //attach connection with the command
                cmd.Connection = con;
                //open connection
                con.Open();
                //Execute the select command from database
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    Product p = new Product
                    {
                        Id = (int)sdr[0],

                        Price = Convert.ToDouble(sdr[2]),
                        Quantity = (int)sdr[3],
                        Description = sdr[4].ToString(),
                        Picture = sdr[5].ToString()
                    };
                    lstproduct.Add(p);

                }
                //Close the data reader and connection
                sdr.Close();
            }
            //Handles Sql Exception
            catch (SqlException ex)
            {
                throw new OSSException(ex.Message);

            }
            //Handles any Other Exception
            catch (Exception ex)
            {
                throw new OSSException(ex.Message);
            }
            finally
            {
                //close connection
                con.Close();

            }

            return lstproduct;
        }
        /// <summary>
        /// This method retrives All the Product Details basing on the Product Id along 
        /// with Description.
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>List of Product with Complete Details</returns>

        public List<Product> GetProductByProductId(int Id)
        {
            List<Product> lstp = new List<Product>();
            try
            {
                //configure Command for SELECT Statement
                cmd = new SqlCommand();
                cmd.CommandText = "select*from Product where Id=" + Id;
                //Pass Value to the Parameter
                cmd.Parameters.Clear();
                //supply values to the parameters of the command
                cmd.Parameters.AddWithValue("@id", Id);
                //specify the type of command
                cmd.CommandType = CommandType.Text;
                //attach connection with the command
                cmd.Connection = con;
                //open connection
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                //Read the records from data reader and add them to the collection
                while (sdr.Read())
                {
                    Product p = new Product
                    {
                        Id = (int)sdr[0],
                        Price = Convert.ToDouble(sdr[2]),
                        Quantity = (int)sdr[3],
                        Description = sdr[4].ToString(),
                        Picture = sdr[5].ToString()
                    };
                    lstp.Add(p);

                }
                //Close the data reader and connection
                sdr.Close();
            }
            //Handles Sql Exception
            catch (SqlException ex)
            {
                throw new OSSException(ex.Message);

            }
            //Handles any Other Exception
            catch (Exception ex)
            {
                throw new OSSException(ex.Message);
            }
            finally
            {
                //close connection
                con.Close();

            }

            return lstp;
        }
        /// <summary>
        /// This method Add Products to the Cart.
        /// </summary>
        /// <param name="Id"></param>
        /// <returns>Added Cart Items</returns>
        public void AddToCart(List<CartItem> cartlst)
        {
            int roweffected;
            try 
            {
                //open Connection
                con.Open();
                foreach(var items in cartlst)
                {
                    //configure Command for INSERT Statement
                    cmd = new SqlCommand();
                    cmd.CommandText = "insert into CartItem(Id,Price,Quantity)values(@id,@pri,@qty)";
                    //Pass Value to the Parameter
                    cmd.Parameters.Clear();
                    //supply values to the parameters of the command
                    cmd.Parameters.AddWithValue("@id", items.Id);
                    cmd.Parameters.AddWithValue("@id", items.Price);
                    cmd.Parameters.AddWithValue("@id", items.Quantity);
                    //specify the type of command
                    cmd.CommandType = System.Data.CommandType.Text;
                    //attach connection with the command
                    cmd.Connection = con;
                    //execute the command
                    roweffected = cmd.ExecuteNonQuery();
                    if(roweffected==0)
                    {
                        throw new Exception("Could not insert data");

                    }
                }
            }
            //Handles Sql Exception
            catch (SqlException ex)
            {
                throw new OSSException(ex.Message);

            }
            //Handles any Other Exception
            catch (Exception ex)
            {
                throw new OSSException(ex.Message);
            }
            finally
            {
                //close connection
                con.Close();

            }
        }

        /// <summary>
        /// This method Add Product to database
        /// </summary>
        /// <param name="p"></param>

        public void AddProduct(Product p)
        {
            try
            {
                //configure Command for INSERT Statement
                cmd = new SqlCommand();
                cmd.CommandText = "insert into Product values(@id,@price,@qty,@desc,@pic)";
                cmd.Connection = con;
                //Pass Value to the Parameter
                cmd.Parameters.Clear();
                //supply values to the parameters of the command
                cmd.Parameters.AddWithValue("@id", p.Id);
                cmd.Parameters.AddWithValue("@price", p.Price);
                cmd.Parameters.AddWithValue("@qty", p.Quantity);
                cmd.Parameters.AddWithValue("@desc", p.Description);
                cmd.Parameters.AddWithValue("@pic", p.Picture);
                //specify the type of command
                cmd.CommandType = CommandType.Text;
                //open connection
                con.Open();
                //execute the command
                cmd.ExecuteNonQuery();
            }
            //Handles Sql Exception
            catch (SqlException ex)
            {
                throw new OSSException(ex.Message);

            }
            //Handles any Other Exception
            catch (Exception ex)
            {
                throw new OSSException(ex.Message);
            }
            finally
            {
                //close connection
                con.Close();

            }
        }
        /// <summary>
        /// This method Delete Product from Database Using Product Id
        /// </summary>
        /// <param name="Id"></param>
        public void DeleteProductById(int Id)
        {
            try
            {
                //configure Command for DELETE Statement
                cmd = new SqlCommand();
                cmd.CommandText = "delete from Product where Id=" + Id;
                cmd.Connection = con;
                //Pass Value to the Parameter
                cmd.Parameters.Clear();
                //specify the type of command
                cmd.CommandType = CommandType.Text;
                //open connection
                con.Open();
                //execute the command
                int recordsAffected = cmd.ExecuteNonQuery();

                if (recordsAffected == 0)
                {
                    throw new Exception("Product does not exist");
                }
            }
            //Handles Sql Exception
            catch (SqlException ex)
            {
                throw new OSSException(ex.Message);

            }
            //Handles any Other Exception
            catch (Exception ex)
            {
                throw new OSSException(ex.Message);
            }
            finally
            {
                //close connection
                con.Close();

            }
        }
        /// <summary>
        /// This method Update Product using Product Id.
        /// </summary>
        /// <param name="p"></param>
        public void UpdateProductById(Product p)
        {
            try
            {
                //configure Command for UPDATE Statement
                cmd = new SqlCommand();
                cmd.CommandText = "update Product set Id=@id,Price=@price,Quantity=@qty where Id=@id";
                //attach connection with the command
                cmd.Connection = con;
                //specify the type of command
                cmd.CommandType = CommandType.Text;
                //Pass Value to the Parameter
                cmd.Parameters.Clear();
                //supply values to the parameters of the command
                cmd.Parameters.AddWithValue("@id", p.Id);
                cmd.Parameters.AddWithValue("@price", p.Price);
                cmd.Parameters.AddWithValue("@qty", p.Quantity);
                //open connection
                con.Open();
                //execute the command
                int recordsAffected = cmd.ExecuteNonQuery();
                con.Close();

                if (recordsAffected == 0)
                {
                    throw new Exception("Product does not exist");
                }

            }
            //Handles Sql Exception
            catch (SqlException ex)
            {
                throw new OSSException(ex.Message);

            }
            //Handles any Other Exception
            catch (Exception ex)
            {
                throw new OSSException(ex.Message);
            }
            finally
            {
                //close connection
                con.Close();

            }
        }
    }
}

   





