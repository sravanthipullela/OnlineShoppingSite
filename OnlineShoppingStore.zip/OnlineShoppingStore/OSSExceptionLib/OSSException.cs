﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OSSExceptionLib
{
    public class OSSException : Exception
    {
        /// <summary>
        /// This method is used To Handle Exception
        /// </summary>
        /// <param name="errMsg"></param>
        public OSSException(string errMsg):base(errMsg)
        {
            //Todo log the error in file
        }
    }
}
